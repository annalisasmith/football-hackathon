import plotly.express as px
import plotly.graph_objs as go

df = df.query("type_name == 'Shot'")
    
df['location_x'] = df['location'].astype(str).str.split(',').str[0]
df['location_y'] = df['location'].astype(str).str.split(',').str[1]
df['location_x'] = df['location_x'].astype(str).str.strip('[')
df['location_x'] = df['location_x'].astype(float)
df['location_y'] = df['location_y'].astype(float)
    
    #for all the oppositions i want the shots to view on the other side of the pitch so am doing 120- location_x
mask = df['team_name'] != 'Manchester City WFC'
df.loc[mask, 'location_x'] = 120 - df.loc[mask, 'location_x']

def plot_shot_location(opposition_team_name):
        
    #defining football pitch size
    football_pitch = go.layout.Shape(
    type='rect',
    x0=0, y0=0, x1=120, y1=80,
    line=dict(color='black', width=2),
    fillcolor='white',
    opacity=0.5
    )

#defining the goals
# define the goal shapes
    left_goal = go.layout.Shape(
    type='rect',
    x0=0, y0=30, x1=6, y1=50,
    line=dict(color='black', width=2),
    opacity= 0.5
    )

    right_goal = go.layout.Shape(
    type='rect',
    x0=114, y0=30, x1=120, y1=50,
    line=dict(color='black', width=2),
    opacity=0.5
    )

# add the halfway line
    halfway_line = go.layout.Shape(
    type='line',
    x0=60, y0=0, x1=60, y1=80,
    line=dict(color='black', width=2, dash='dash'),
    opacity=0.5
    )

    left_penalty_box = go.layout.Shape(
    type= 'rect',
    x0=0,y0=18,x1=18,y1=62,
    line=dict(color ='black',width=2),
    opacity=0.5
    )

    right_penalty_box = go.layout.Shape(
    type = 'rect',
    x0=102,y0=18,x1=120,y1=62,
    line=dict(color='black',width=2),
    opacity=0.5
    )

    center_dot = go.layout.Shape(
    type='circle',
    xref='x', yref='y',
    x0=59.5, y0=39.5, x1=60.5, y1=40.5,
    line=dict(color='black', width=1),
    fillcolor='black',
    opacity=0.5
    )

    penalty_dot_left = go.layout.Shape(
    type='circle',
    xref= 'x', yref='y',
    x0=11.5,y0=39.5,x1=12.5,y1=40.5,
    line=dict(color='black', width=1),
    fillcolor='black',
    opacity=0.5
    )

    penalty_dot_right = go.layout.Shape(
    type='circle',
    xref= 'x', yref='y',
    x0=107.5,y0=39.5,x1=108.5,y1=40.5,
    line=dict(color='black', width=1),
    fillcolor='black',
    opacity=0.5
    )

    center_circle = go.layout.Shape(
    type='circle',
    xref= 'x', yref='y',
    x0=50,y0=30,x1=70,y1=50,
    line=dict(color='black', width=1),
    opacity=0.5
    )

# create the layout
    layout = go.Layout(
    title='Football Pitch',
    xaxis=dict(range=[0, 120], showgrid=False),
    yaxis=dict(range=[80, 0], showgrid=False),
    shapes=[football_pitch, left_goal, right_goal, halfway_line, left_penalty_box, right_penalty_box, center_dot,
           penalty_dot_left, penalty_dot_right, center_circle],
    width=1000, height=600,
    margin=dict(l=40, r=40, b=40, t=80)

    )
    shot_df= df[df['opposition'] == opposition_team_name]
    trace_all = px.scatter(shot_df, x='location_x', y='location_y', color='team_name', opacity=1,
                       size_max=15, #color_discrete_map={'Manchester City WFC':'blue', 'Tottenham Hotspur Women':'green'},
                       hover_name = 'player_name',
                       hover_data = ['team_name','position_name', 'shot_outcome.name','minute', 'period'])
    
    # filter DataFrame to include only shots taken during period 1
    df_period1 = shot_df[shot_df['period'] == 1]
                
# filter DataFrame to include only shots taken during period 2
    df_period2 = shot_df[shot_df['period'] == 2]
                
# create scatter plot for shots in period 1
    trace_p1 = px.scatter(df_period1, x = 'location_x', y='location_y', title= 'Shot Locations- First Half',
                      size_max=15, opacity=1, color='team_name',
                     hover_name = 'player_name', hover_data = ['team_name','position_name', 'shot_outcome.name',
                                                               'minute', 'period'])

# create scatter plot for shots in period 2
    trace_p2 = px.scatter(df_period2, x = 'location_x', y='location_y', title= 'Shot Locations- Second Half', size_max=15,
                     opacity = 1, color='team_name',
                      hover_name = 'player_name', hover_data = ['team_name','position_name', 'shot_outcome.name',
                                                               'minute', 'period'])
    
    

    
   # add the football pitch layout to the scatter plot figure
    fig_all = go.Figure(layout=layout)
    
        # create dropdown menu
    fig_all.update_layout(
    updatemenus=[
        dict(
            buttons=[
                dict(label='All Shots',
                     method='update',
                     args=[{'visible': [True, True, False, False, False, False]},
                           {'title': 'All Shots'}]),
                dict(label='First Half Shots',
                     method='update',
                     args=[{'visible': [False, False, True, True, False, False]},
                           {'title': 'First Half Shots'}]),
                dict(label='Second Half Shots',
                     method='update',
                     args=[{'visible': [False, False, False,False, True, True]},
                           {'title': 'Second Half Shots'}])
            ],
            direction='down',
            showactive=True
        )
    ]
    )
    
    fig_all.add_trace(trace_all.data[0])
    fig_all.add_trace(trace_all.data[1])
    fig_all.add_trace(trace_p1.data[0])
    fig_all.add_trace(trace_p1.data[1])
    fig_all.add_trace(trace_p2.data[0])
    fig_all.add_trace(trace_p2.data[1])
    
    
    fig_all.show()