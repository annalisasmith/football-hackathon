from django.shortcuts import render, redirect
from cluster_footie import *
import os
import time


def defence_page(request):

    # replace with the path to your folder
    folder_path = "static/defence/imgs/cluster_images"

    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                os.rmdir(file_path)
        except Exception as e:
            print(f"Failed to delete {file_path}. Reason: {e}")

    if request.method == "POST":

        df_arsenal_events = pd.read_json('Data/ManCity_Arsenal_events.json') 
        df_aston_events = pd.read_json('Data/ManCity_AstonVilla_events.json')
        df_brighton_events = pd.read_json('Data/ManCity_Brighton_events.json')
        df_leicester_events = pd.read_json('Data/ManCity_LeicesterCity_events.json')
        df_liverpool_events = pd.read_json('Data/ManCity_Liverpool_events.json')
        df_tottenham_events = pd.read_json('Data/ManCity_Tottenham_events.json')

        df_all_events = pd.concat([
            df_arsenal_events,
            df_aston_events,
            df_brighton_events,
            df_leicester_events,
            df_liverpool_events,
            df_tottenham_events]).reset_index().drop(
                columns=['level_0', 'index']
                )

        period = int(request.POST.get('period'))

        df_auto = auto_process(
            df_all_events=df_all_events,
            TeamID=746,
            Period=period)

        clust_groups = df_auto['cluster_group'].tolist()

        loss_per = [
            round(item, 2) for item in df_auto['loss_percentage'].tolist()
            ]

        c_groups = list(zip(clust_groups, loss_per))

        return render(request, 'analysis.html', {'lin_length': c_groups})

    return render(request, 'defence.html')