import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt


def quadrants(coords):
    """
    Takes in x, y coordinates and assigns quadrant label.
    """
    try:
        x, y = coords

        if x > 60 and y < 40:  # top right
            return 'Q2'
        elif x > 60 and y >= 40:  # bottom right
            return 'Q3'
        elif x <= 60 and y < 40:  # top left
            return 'Q1'
        elif x == 60 and y == 40:  # centre
            return 'Centre'
        else:
            return 'Q4'
    except TypeError:
        return np.nan
    except ValueError:
        return np.nan


def prepare_df(df, teamID, period):
    """
    Adds columns and filters for a specified team and game half
    e.g., first half. The returned DataFrame is ready to be clustered
    using the dynamic clustering module.
    """
    df_cleaned = df.copy()

    type_id = []
    type_name = []

    for types in df_cleaned['type'].values:
        type_id.append(types['id'])
        type_name.append(types['name'])

    df_cleaned['type_name'] = type_name
    df_cleaned['type_id'] = type_id

    df_cleaned.drop(columns='type', inplace=True)

    play_pattern_name = []
    play_pattern_id = []

    for pattern in df_cleaned['play_pattern'].values:
        play_pattern_name.append(pattern['name'])
        play_pattern_id.append(pattern['id'])

    df_cleaned['play_pattern_name'] = play_pattern_name
    df_cleaned['play_pattern_id'] = play_pattern_id

    df_cleaned.drop(columns='play_pattern', inplace=True)

    df_cleaned['event_quadrant'] = df_cleaned.apply(
        lambda row: quadrants(row['location']), axis=1)

    df_cleaned = df_cleaned.loc[(
        (df_cleaned['type_name'] == 'Dispossessed') |
        (df_cleaned['type_name'] == 'Miscontrol')
        ), [
        'type_name',
        'event_quadrant',
        'location',
        'obv_against_after',
        'position',
        'possession_team',
        'period',
        'player'
        ]]

    player_name = []
    player_id = []

    for player in df_cleaned['player'].values:
        try:
            player_name.append(player['name'])
            player_id.append(player['id'])
        except TypeError:
            player_name.append(np.nan)
            player_id.append(np.nan)

    df_cleaned['player_name'] = player_name
    df_cleaned['player_id'] = player_id

    df_cleaned.drop(columns='player', inplace=True)

    x_event = []
    y_event = []

    for x, y in df_cleaned['location'].values:
        x_event.append(x)
        y_event.append(y)

    df_cleaned['x_coord'] = x_event
    df_cleaned['y_coord'] = y_event

    df_cleaned.drop(columns='location', inplace=True)

    position_name = []
    position_id = []

    for position in df_cleaned['position'].values:
        position_id.append(position['id'])
        position_name.append(position['name'])

    df_cleaned['position_name'] = position_name
    df_cleaned['position_id'] = position_id

    df_cleaned.drop(columns='position', inplace=True)

    team_name = []
    team_id = []

    for team in df_cleaned['possession_team'].values:
        team_id.append(team['id'])
        team_name.append(team['name'])

    df_cleaned['team'] = team_name
    df_cleaned['team_id'] = team_id

    df_cleaned.drop(columns='possession_team', inplace=True)

    df_cleaned = df_cleaned.loc[((df_cleaned['team_id'] == teamID) & (
        df_cleaned['period'] == period)), :]

    return df_cleaned


def dynamic_cluster(df):
    """
    The entered DataFrame is extraced for its x,y coordinates.
    The coordinates are cluster into n groups. n is determined
    by the highest silhouette score. The function returns the
    pre-trained model; it also creates a scatter plot which is
    saved to the path.
    """

    # Import required libraries
    import matplotlib.pyplot as plt
    from scipy.stats import multivariate_normal
    from sklearn.mixture import GaussianMixture
    from sklearn.metrics import silhouette_score
    import warnings

    warnings.filterwarnings('ignore')

    # Create an array from the x and y coordinates in a Pandas DataFrame
    X = np.array(df[['x_coord', 'y_coord']])

    # Create an empty dictionary to store silhouette scores
    # for different numbers of clusters
    sils = {}

    # Loop through different numbers of clusters from 2 to 10
    for n in range(2, 11):
        # Fit a Gaussian mixture model with n components
        gmm = GaussianMixture(n_components=n)
        gmm.fit(X)

        # Make predictions and get the silhouette score
        labels = gmm.predict(X)
        sils[n] = silhouette_score(X, labels=labels)

    # Find the number of clusters with the highest silhouette score
    best_n_clusters = max(sils, key=sils.get)

    # Set the random seed to ensure reproducibility
    np.random.seed(1)

    # Fit a Gaussian mixture model with the optimal number of clusters
    gmm = GaussianMixture(n_components=best_n_clusters)
    gmm.fit(X)

    # Make predictions and get the means and covariances of each cluster
    labels = gmm.predict(X)
    means = gmm.means_
    covariances = gmm.covariances_

    # Create an empty dictionary to store PDF values for plotting
    gmm_plots = {}

    # Create a meshgrid to plot the PDF values
    # x, y = np.meshgrid(np.linspace(0, 120, 100), np.linspace(0, 80, 100))

    x, y = np.meshgrid(range(0, 121), range(80, -1, -1))
    pos = np.empty(x.shape + (2, ))
    pos[:, :, 0] = x
    pos[:, :, 1] = y

    # Loop through each cluster and calculate its PDF values
    for num, mean_cov in enumerate(zip(means, covariances)):
        num += 1
        mean, cov = mean_cov
        gmm_plots[f'z{num}'] = multivariate_normal.pdf(pos, mean=mean, cov=cov)

    # Assign cluster labels to the original DataFrame
    df['cluster_group'] = labels

    # Create a new figure and set its size and DPI
    plt.figure(figsize=(12, 6), dpi=200)

    # Plot the contours of the PDF values for each cluster
    for key in gmm_plots.keys():
        plt.contour(x, y, gmm_plots[key], levels=3, colors='black')

    # Plot the data points colored by their cluster labels
    sns.scatterplot(data=df, x='x_coord', y='y_coord',
                    hue='cluster_group', palette='tab10')

    # # Add a legend to the plot
    plt.legend()

    img = plt.imread('static/defence/imgs/football_pitch.jpg')

    # # Load and display an image as the background of the plot
    plt.imshow(img, extent=[0, 120, 0, 80], aspect='auto')

    plt.savefig('static/defence/imgs/footie.png', transparent=True)

    return gmm


def ratio_calc(df_all_events, df_man_city, gmm):
    """
    Uses pre-trained clustering model to group
    a DataFrame by cluster number. Calculates
    ball loss percentage by cluster.
    """

    df = df_all_events.copy()[['type', 'location', 'team']]

    df.dropna(inplace=True)

    x_coord = []
    y_coord = []

    for location in df['location'].values:
        if len(location) == 3:
            x, y, z = location
        else:
            x, y = location
        x_coord.append(x)
        y_coord.append(y)

    df['x_coord'] = x_coord
    df['y_coord'] = y_coord

    event_name = []

    for type_ in df['type'].values:
        event_name.append(type_['name'])

    df['event_name'] = event_name

    df.drop(columns=['type', 'location', 'team'], inplace=True)

    X = np.array(df[['x_coord', 'y_coord']])

    labels = gmm.predict(X)

    df['cluster_group'] = labels

    df = df.loc[(
                    (df['event_name'] == 'Pass') |
                    (df['event_name'] == 'Carry') |
                    (df['event_name'] == 'Miscontrol') |
                    (df['event_name'] == 'Interception') |
                    (df['event_name'] == 'Dispossessed') |
                    (df['event_name'] == 'Dribble')
                ),
                :
                ]

    df_all = df.groupby('cluster_group')['event_name'].count().reset_index()

    df_loss = df_man_city.groupby('cluster_group')[
        'type_name'].count().reset_index()

    df_ratio = df_all.merge(df_loss, on='cluster_group')

    df_ratio['loss_percentage'] = (
        df_ratio['type_name'] / df_ratio['event_name']) * 100

    return df_ratio


def auto_process(df_all_events, TeamID=746, Period=1):
    """
    Packages all functions together.
    """

    df_man_city = prepare_df(df_all_events, TeamID, period=Period)

    gmm = dynamic_cluster(df_man_city)

    play_pattern_cluster(df_all_events, df_man_city)

    return ratio_calc(
                     df_all_events=df_all_events,
                     df_man_city=df_man_city,
                     gmm=gmm
                     )


def play_pattern_cluster(df_all_events, df_man_city):
    """
    Makes a pdf of plots. The plots contain the count
    of ball losses by play pattern and cluster group.
    """

    from matplotlib.backends.backend_pdf import PdfPages

    from datetime import date

    df_all_events_copy = df_all_events.copy()

    play_pattern = []

    for pattern in df_all_events_copy['play_pattern']:
        play_pattern.append(pattern['name'])

    df_all_events_copy['play_pattern_name'] = play_pattern

    with PdfPages(f'cluster_plot_{date.today()}.pdf') as pdf:

        for cluster in sorted(df_man_city['cluster_group'].unique()):

            test = df_all_events_copy.iloc[
                df_man_city.loc[
                    df_man_city['cluster_group'] == cluster,
                    :].index
                ]

            test_dict = test.groupby('play_pattern_name')[
                'id'].count().to_dict()

            full_dict = {}

            full_dict['play_pattern'] = list(test_dict.keys())

            full_dict['count'] = list(test_dict.values())

            plt.figure(figsize=(15, 10))  # add dpi

            sns.barplot(data=full_dict, x='play_pattern', y='count')

            plt.title(
                f'Number of Ball Loss Events by Play Pattern in {cluster}',
                fontsize=25)

            plt.xticks(fontsize=12)
            plt.xlabel('Play Pattern', fontsize=20, labelpad=20)

            plt.yticks(fontsize=12)
            plt.ylabel('Number of Events', fontsize=20, labelpad=20)

            pdf.savefig()

    pdf.close
