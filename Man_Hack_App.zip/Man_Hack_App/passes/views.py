from django.shortcuts import render
from ann_work.vsproject.myapp.passes import football_match

# Create your views here.
def pass_page(request):

    if request.method == "POST":

        team_name = request.POST.get('team_name')
        
        # User input for plot creation
        pass_plot = football_match(team_name)
        
        return render(
            request,
            'passes.html',
            {'team': team_name, 'plot_div': pass_plot}
            )

    return render(request, 'passes.html')
