from django.shortcuts import render
from shot_function_final import full_shot_plot

# Create your views here.

def show_shots(request):
    if request.method == "POST":  # Check for opponent team name input
        team_name = request.POST.get('team_name')
        pass_plot = full_shot_plot(opposition=team_name)  # User input for plot creation
        return render(request, 'shot_plot.html', {'team': team_name, 'plot_div': pass_plot})
    else:
        return render(request, 'shot_plot.html')  # Otherwise display empty page, no plot
