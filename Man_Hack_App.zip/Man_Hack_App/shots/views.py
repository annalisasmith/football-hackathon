from django.shortcuts import render

# Create your views here.

def shots_page(request):
    return render(request, 'shots.html')
