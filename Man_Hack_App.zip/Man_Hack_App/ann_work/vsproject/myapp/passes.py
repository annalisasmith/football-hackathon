import pandas as pd
import plotly.express as px
from plotly.offline import plot


def cleaning_ting(path):

    # read in the JSON file and select columns of interest
    df = pd.read_json(path)
    df = df[['player', 'pass', 'team', 'position']]

    # extract the embedded JSON from multiple columns into new DataFrames
    team_df = pd.json_normalize(df['team']).rename(columns={'id': 'team_id', 'name': 'team_name'})
    player_df = pd.json_normalize(df['player']).rename(columns={'id': 'player_id', 'name': 'player_name'})
    position_df = pd.json_normalize(df['position']).rename(columns={'id': 'position_id', 'name': 'position_name'})
    pass_df = pd.json_normalize(df['pass']).add_prefix('pass_')

    # merge all the new DataFrames together
    result = pd.concat([df, team_df, player_df, position_df, pass_df], axis=1)

    # drop the original columns that were extracted
    result = result.drop(['player', 'pass', 'team', 'position'], axis=1)

    return result

def football_match(opponent: str):
    opponent = opponent.title()  # Takes team name input from user and formats for file reference
    
    path = f"Data/ManCity_{opponent}_events.json"
    
    df = cleaning_ting(path)

    cols = []

    for column in df.columns:
        cols.append(str(column).replace('.', '_'))

    df.columns = cols

    # Filters data for only Manchester City club
    pass_df = df[df["team_name"] == "Manchester City WFC"].dropna(how="all")

    # Filtering and formatting
    pass_df["pass_length"] = pass_df["pass_length"].round(1)
    pass_df["pass_outcome_name"] = pass_df["pass_outcome_name"].fillna("None")

    # Fixing coordinates from string to floats
    for index, row in pass_df.iterrows():
        if isinstance(pass_df["pass_end_location"][index], str):
            pass_df["pass_end_location"][index] = (
                pass_df["pass_end_location"][index].strip("[]").split(",")
            )

    def is_pass_end_location_list(row):
        return isinstance(row["pass_end_location"], list)

    pass_df = pass_df[pass_df.apply(is_pass_end_location_list, axis=1)]

    for index, row in pass_df.iterrows():
        pass_df.loc[index, "pass_end_location_x"] = float(row["pass_end_location"][0])
        pass_df.loc[index, "pass_end_location_y"] = float(row["pass_end_location"][1])

    # Plots end location points
    fig = px.scatter(
        pass_df,
        x="pass_end_location_x",
        y="pass_end_location_y",
        color="pass_recipient_name",
        hover_name="pass_recipient_name",
        hover_data={
            "player_name": True,
            "pass_length": True,
            "position_name": True,
            "pass_outcome_name": True,
            "pass_end_location_x": False,
            "pass_end_location_y": False,
        },
        title="All Players",
        width=1000,
        height=600
    )

    # create dropdown menu for selecting players
    player_list = list(pass_df["pass_recipient_name"].dropna().unique())

    buttons = []
    for name in player_list:
        visible = [False] * len(player_list)
        visible[player_list.index(name)] = True
        button = dict(
            label=name, method="update", args=[{"visible": visible}, {"title": name}]
        )
        buttons.append(button)

    # add dropdown menu to the layout
    fig.update_layout(
        xaxis=dict(range=[0, 120]),
        yaxis=dict(range=[80, 0]),
        updatemenus=[
            dict(
                buttons=[
                    dict(
                        label="All",
                        method="update",
                        args=[{"visible": [True] * len(player_list)}, {"title": "All"}],
                    )
                ]
                + buttons,
                direction="down",
                showactive=True,
                x=1.05,
                y=0.5,
            )
        ],
    )

    plot_div = plot(fig, output_type="div")

    return plot_div
