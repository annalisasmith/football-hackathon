from django.urls import path
from . import views

# URLConf
urlpatterns = [
    path('webpage/', views.show_passes),
]