
import pandas as pd
from ann_work.vsproject.myapp.passes import cleaning_ting


path = "Data/ManCity_Arsenal_events.json"

df = cleaning_ting(path)

print(df.columns)