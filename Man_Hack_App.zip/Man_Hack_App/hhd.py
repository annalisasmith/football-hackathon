from shot_function_final import shot_trans_dataframe, plot_shot_location, full_shot_plot
from ann_work.vsproject.myapp.passes import football_match


# print(football_match('Arsenal'))


df = shot_trans_dataframe('Data/all_games.csv')

# print(df.loc[df['team_name'] == 'Arsenal WFC', :])

print(df['opposition'].unique())

print(plot_shot_location(df=df, opposition_team_name='Aston Villa'))