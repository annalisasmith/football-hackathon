from django.shortcuts import render
from .passes import *


def show_passes(request):
    if request.method == "POST":  # Check for opponent team name input
        team_name = request.POST.get('team_name')
        pass_plot = football_match(team_name)  # User input for plot creation
        return render(request, 'webpage.html', {'team': team_name, 'plot_div': pass_plot})
    else:
        return render(request, 'webpage.html')  # Otherwise display empty page, no plot
