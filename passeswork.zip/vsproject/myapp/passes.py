import pandas as pd
import plotly.express as px
from plotly.offline import plot


def football_match(opponent: str):
    opponent = opponent.title()  # Takes team name input from user and formats for file reference
    path = f"data/cleaned_ManCity_{opponent}_events.csv"
    df = pd.read_csv(path)

    # Filters data for only Manchester City club
    pass_df = df[df["team_name"] == "Manchester City WFC"].dropna(how="all")

    # Filtering and formatting
    pass_df["pass_length"] = pass_df["pass_length"].round(1)
    pass_df["pass_outcome.name"] = pass_df["pass_outcome.name"].fillna("None")

    # Fixing coordinates from string to floats
    for index, row in pass_df.iterrows():
        if isinstance(pass_df["pass_end_location"][index],str):
            pass_df["pass_end_location"][index] = (
                pass_df["pass_end_location"][index].strip("[]").split(",")
            )

    def is_pass_end_location_list(row):
        return isinstance(row["pass_end_location"], list)

    pass_df = pass_df[pass_df.apply(is_pass_end_location_list, axis=1)]

    for index, row in pass_df.iterrows():
        pass_df.loc[index, "pass_end_location_x"] = float(row["pass_end_location"][0])
        pass_df.loc[index, "pass_end_location_y"] = float(row["pass_end_location"][1])

    # Plots end location points
    fig = px.scatter(
        pass_df,
        x="pass_end_location_x",
        y="pass_end_location_y",
        color="pass_recipient.name",
        hover_name="pass_recipient.name",
        hover_data={
            "player_name": True,
            "pass_length": True,
            "position_name": True,
            "pass_outcome.name": True,
            "pass_end_location_x": False,
            "pass_end_location_y": False,
        },
        title="All Players",
    )

    # create dropdown menu for selecting players
    player_list = list(pass_df["pass_recipient.name"].dropna().unique())

    buttons = []
    for name in player_list:
        visible = [False] * len(player_list)
        visible[player_list.index(name)] = True
        button = dict(
            label=name, method="update", args=[{"visible": visible}, {"title": name}]
        )
        buttons.append(button)

    # add dropdown menu to the layout
    fig.update_layout(
        xaxis=dict(range=[0, 120]),
        yaxis=dict(range=[80, 0]),
        updatemenus=[
            dict(
                buttons=[
                    dict(
                        label="All",
                        method="update",
                        args=[{"visible": [True] * len(player_list)}, {"title": "All"}],
                    )
                ]
                + buttons,
                direction="down",
                showactive=True,
                x=1.05,
                y=0.5,
            )
        ],
    )
    plot_div = plot(fig, output_type="div")

    return plot_div
